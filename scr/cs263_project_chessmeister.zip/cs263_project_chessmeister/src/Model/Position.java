package Model;

import Enums.Files;
import Enums.Rank;

public class Position {
	
	private Rank rank;
	private Files file;

}
