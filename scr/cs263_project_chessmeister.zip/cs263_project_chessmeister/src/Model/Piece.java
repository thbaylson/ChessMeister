package Model;

import Enums.ChessPieceType;
import Interfaces.PieceIF;

public class Piece extends BlackAndWhite implements PieceIF{

	@Override
	public ChessPieceType getChessPieceType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setChessPieceType(ChessPieceType t) {
		// TODO Auto-generated method stub
		
	}

}
