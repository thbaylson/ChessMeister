package Model;

import Interfaces.PieceIF;
import Interfaces.SquareIF;

public class Square extends BlackAndWhite implements SquareIF{

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPiece(PieceIF p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public PieceIF getPiece() {
		// TODO Auto-generated method stub
		return null;
	}

}
