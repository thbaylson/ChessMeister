package Interfaces;

import Enums.GameColor;

public interface BlackAndWhiteIF {

	public GameColor getColor();
	
	public boolean isBlack();
	
	public boolean isWhite();
	
	
	
	
}
