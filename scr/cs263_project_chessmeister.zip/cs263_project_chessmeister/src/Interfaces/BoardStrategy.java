package Interfaces;

public interface BoardStrategy {
	
	
	public void draw(BoardIF board);
	
}
