package Interfaces;

import Enums.ChessPieceType;

public interface PieceIF {

	
	public ChessPieceType getChessPieceType();
	
	public void setChessPieceType(ChessPieceType t);	
	
	
	
}
