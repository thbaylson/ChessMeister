package UI_CLI;

import Interfaces.BoardIF;
import Interfaces.BoardStrategy;

public class Board_Color_CLI implements BoardStrategy{

	@Override
	public void draw(BoardIF board) {
		// TODO Auto-generated method stub
		
	}

}
