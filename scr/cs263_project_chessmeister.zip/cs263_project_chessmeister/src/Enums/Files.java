package Enums;

public enum Files {
	
	A, B, C, D, E, F, G, H

}
