package Enums;

public enum ChessPieceType {
	
	King, Queen, Rook, Bishop, Knight, Pawn

}
