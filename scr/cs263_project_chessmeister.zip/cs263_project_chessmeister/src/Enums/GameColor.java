package Enums;

public enum GameColor {
	
	Black, White

}
